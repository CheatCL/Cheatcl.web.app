---
sidebar_position: -1
---

# 👍・Hello Launcher For Win 64/32

100% no rat

![cac](hello.png)
[Download.exe (no rat 100%)](https://github.com/frenda-r/-/releases/download/1/HMCL.exe)