---
sidebar_position: 1
---

# Nursultan Client V6.5

[Download](https://firebasestorage.googleapis.com/v0/b/frendacute.appspot.com/o/Nur%206.5.rar?alt=media&token=9cb8e734-3c9f-4b17-acc0-9a88c4b98027)