---
sidebar_position: 1
---

# Vape Free !!


import Tabs from '@theme/Tabs';
import TabItem from '@theme/TabItem';

<Tabs>
  <TabItem value="Eng" label="Eng" default>

## Cre : VudungVape
```
https://discord.gg/4CSkxbYRSN
```
# Step 1

Download jdk 20 here https://download.oracle.com/java/20/archive/jdk-20_windows-x64_bin.exe 

# Step 2

https://drive.google.com/file/d/1G3uEob7FIbbQO4DVN04hHJxWYNmJqPxn/view?usp=drivesdk
Download this file
Password : vudungvapev4

# Step 3
Open Lunar client - Soar Client - Badlion (latest version cracked allowed)

 in main menu go singleplayer create a map and launch bapeclient.bat, and waiting until the console said: “done ! took ** ms” and close the console.

Press RSHIFT and enjoy!

p.s: (this crack was made by @Decencies not mine)

If u get a issue while installing vape please tag @helper in our server


### cre:
Minecraft Cheater Central(MCC)

```
https://discord.gg/4CSkxbYRSN
```

  </TabItem>
  <TabItem value="Vi" label="Vi">

## Cre: Vudungvape
# Bước 1

Tải xuống jdk 20 tại đây https://download.oracle.com/java/20/archive/jdk-20_windows-x64_bin.exe
# Bước 2

https://drive.google.com/file/d/1G3uEob7FIbbQO4DVN04hHJxWYNmJqPxn/view?usp=drivesdk Tải file này Mật khẩu : vudungvapev4
# Bước 3

Mở client Lunar - Soar Client - Badlion (đã cho phép crack bản mới nhất)

trong menu chính, hãy chuyển sang phần chơi đơn, tạo bản đồ và khởi chạy bapeclient.bat, và đợi cho đến khi bảng điều khiển thông báo: “xong! lấy ** ms” và đóng bảng điều khiển.

Nhấn RSHIFT và tận hưởng!

p.s: (bản crack này được tạo bởi @Decencies không phải của tôi)

Nếu bạn gặp sự cố khi cài đặt vape, vui lòng gắn thẻ @helper vào máy chủ của chúng tôi
  </TabItem>
</Tabs>


