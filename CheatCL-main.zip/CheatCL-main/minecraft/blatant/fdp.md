---
sidebar_position: 1
---

# FDP

## Feature
- free
- good bypass

## Download Here: [FDP v4 Clean](https://github.com/frenda-r/-/releases/download/1/FDP.Client.Cleanver4.jar) (CleanVer)
## Download Here: [FDP v3 Clean](https://github.com/frenda-r/-/releases/download/1/FDPClient-3.1.1.zip) (CleanVer)
## Download Here: [Main Site](https://fdpinfo.github.io/next/) (Rat?)
