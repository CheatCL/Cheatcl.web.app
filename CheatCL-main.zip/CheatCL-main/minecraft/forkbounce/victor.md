---
sidebar_position: 1
---

# Victor Client

## Download Here: [Clean](https://github.com/frenda-r/-/releases/download/lbfork/victor.v3.zip)