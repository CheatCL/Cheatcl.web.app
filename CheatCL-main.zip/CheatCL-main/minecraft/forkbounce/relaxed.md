---
sidebar_position: 1
---

# Relaxed Client

## Download Here: [Clean](https://github.com/frenda-r/-/releases/download/lbfork/Relaxed.Client1.12.2-Cracked.jar)