---
sidebar_position: 1
---

# Wind Client

## Download Here: [Clean](https://github.com/frenda-r/-/releases/download/lbfork/WindX.zip)
## Download Here: [b9](https://github.com/frenda-r/-/releases/download/lbfork/WindXB9Crk.zip)
## Download Here: [Paid ver](https://github.com/frenda-r/-/releases/download/lbfork/WindXCracked.7z)