---
sidebar_position: 1
---

# ColorByte Client

## Download Here: [1.5](https://github.com/frenda-r/-/releases/download/lbfork/colorbyte-1.5-dev.build.cracked.jar)
## Download Here: [1.7](https://github.com/frenda-r/-/releases/download/lbfork/colorbyte-1.7-dev.build.cracked.jar)