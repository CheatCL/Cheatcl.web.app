---
sidebar_position: 1
---

# Raven b++

## Feature
- free
- no rat !!
- autoclick
- aimbot
- velocity
- ...

## Download Here: [Raven B++](https://github.com/frenda-r/-/releases/download/1/1.8.9.BetterKeystrokes.V-1.2.jar)
## Download Here: [Raven B++ (sigma)](https://github.com/frenda-r/-/releases/download/1/1.8.9.BetterKeystrokes.sigma.jar)
