---
sidebar_position: 0
slug: /
---

# Intro

how to code & skid ramdom client