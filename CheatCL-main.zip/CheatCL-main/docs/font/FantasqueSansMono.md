---
sidebar_position: 1
---

# FantasqueSansMono

Link : [Download](https://firebasestorage.googleapis.com/v0/b/frendacute.appspot.com/o/FantasqueSansMono.zip?alt=media&token=f8984962-d938-4f2a-bd09-f58f8ff86877)   