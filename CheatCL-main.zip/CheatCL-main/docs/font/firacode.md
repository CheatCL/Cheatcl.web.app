---
sidebar_position: 1
---

# FiraCode

Link : [Download](https://firebasestorage.googleapis.com/v0/b/frendacute.appspot.com/o/FiraCode.zip?alt=media&token=106f0ae1-3d8b-4e3b-ba83-b00841c8a598)   